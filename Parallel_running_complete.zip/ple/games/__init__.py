
a = 1
from .catcher import Catcher
from .flappybird import FlappyBird
from .monsterkong import MonsterKong
from .pixelcopter import Pixelcopter
from .pong import Pong
from .puckworld import PuckWorld
from .raycastmaze import RaycastMaze
from .snake import Snake
from .waterworld import WaterWorld
